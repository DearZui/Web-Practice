```
$ cd generateSummary
$ npm install
$ mocha --compilers js:babel-core/register
```
---
可能JavaScript多行输入的原因，Mocha测试并不能通过，但在浏览器console中可以正确输出
![example](http://obydp3y41.bkt.clouddn.com/example.jpg)